set(CMAKE_HOST_SYSTEM "Darwin-25.4.0")
set(CMAKE_HOST_SYSTEM_NAME "Darwin")
set(CMAKE_HOST_SYSTEM_VERSION "25.4.0")
set(CMAKE_HOST_SYSTEM_PROCESSOR "arm64")

include("/Users/nickshroff/Library/Android/sdk/ndk/28.0.13004108/build/cmake/android.toolchain.cmake")

set(CMAKE_SYSTEM "Android-1")
set(CMAKE_SYSTEM_NAME "Android")
set(CMAKE_SYSTEM_VERSION "1")
set(CMAKE_SYSTEM_PROCESSOR "x86_64")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
